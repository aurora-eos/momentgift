export type Furniture = {id:string; name:string;x:number;y:number;w:number;h:number;text:string};
export const furniture:Furniture[]=[
{id:'shelf',name:'书架',x:55,y:79,w:42,h:40,text:'书页间夹着一张纸条：“有些心意，藏在最日常的地方。”去看看房间里的抽屉吧。'},
{id:'plant',name:'花盆',x:272,y:86,w:22,h:30,text:'新叶正悄悄长出来。花盆底下写着：“愿你的每一天，都有新的期待。”'},
{id:'drawer',name:'抽屉',x:270,y:164,w:38,h:28,text:'你轻轻拉开抽屉，在柔软的布料中找到了一把金色钥匙！它应该能打开放在门边的信箱。'},
{id:'mail',name:'信箱',x:65,y:191,w:24,h:28,text:'信箱上挂着一把小锁。似乎需要一把金色钥匙……'}];
