import Phaser from 'phaser';
import {drawGarden,gardenObjects} from './Garden';
import {furniture,type Furniture} from './config';
import {themes,type Mode} from './themes';
export class Room extends Phaser.Scene {
 player!:Phaser.GameObjects.Container; keys!:Record<string,Phaser.Input.Keyboard.Key>; near?:Furniture; hint!:Phaser.GameObjects.Text; locked=false; private moving=false;
 constructor(private onExplore:(f:Furniture)=>void, private mode:Mode='normal'){super('room')}
 create(){
 const t=themes[this.mode],g=this.add.graphics();const r=(x:number,y:number,w:number,h:number,c:number,a=1)=>{g.fillStyle(c,a).fillRect(x,y,w,h)};
 r(0,0,360,270,t.edge);r(12,12,336,246,0x251f27,.3);r(17,14,326,235,t.wall);r(24,68,312,177,t.floor);
 // wood grain and staggered planks
 for(let y=68;y<245;y+=16){r(24,y,312,1,0x654732,.35);for(let x=24+(y%32?0:28);x<336;x+=56){r(x,y,1,16,0x654732,.22);r(x+9,y+6,20,1,0xffe0ad,.16);r(x+30,y+11,10,1,0x654732,.12)}}
 r(18,60,324,8,0x6c5144);r(20,61,320,2,0xf4d8ad);r(18,68,6,177,0x674c40);r(336,68,6,177,0x674c40);r(24,243,312,5,0x5d473c);
 // wallpaper, picture frames
 for(let x=31;x<336;x+=12)for(let y=22;y<57;y+=12){r(x,y,1,2,0xffffff,.35);r(x+1,y+1,2,1,0xffffff,.3)}
 r(109,20,102,44,0x6c5149);r(112,22,96,39,t.sky);r(158,23,3,38,0xf5e5c6);r(113,41,94,3,0xf5e5c6);r(108,61,104,5,0xd8b58a);
 if(this.mode==='normal'){r(115,47,41,12,0x91ad9a);r(161,49,45,11,0x799782);r(184,28,9,9,0xffe1a0);g.fillStyle(0xffe4a4,.11).fillPoints([{x:117,y:65},{x:193,y:65},{x:262,y:209},{x:156,y:209}],true)}
 if(this.mode==='birthday'){for(let i=0;i<16;i++){r(115+i*5,28+(i*7%23),2,3,[0xffe7ad,0xf7a8b3,0x9585b4][i%3])}for(let x=82;x<278;x+=17){r(x,18+Math.round(Math.sin(x/70)*5),14,1,0xc2998f);for(let j=0;j<6;j++)r(x+j,20+Math.round(Math.sin(x/70)*5)+j,12-j*2,1,[0xc67d94,0xe9bb72,0x8daaa2][Math.floor(x/17)%3])}}
 if(this.mode==='newyear'){for(const [x,y,c] of [[137,34,0xf5c376],[185,35,0xe89c89]] as const){for(let i=0;i<8;i++){const a=i*Math.PI/4;r(x+Math.round(Math.cos(a)*9),y+Math.round(Math.sin(a)*9),2,2,c)}r(x,y,2,2,0xffedb6)}for(const x of [89,229]){r(x+7,18,1,8,0xc48a43);r(x+2,26,12,2,0xe3b45e);r(x,28,16,17,0xa53f36);r(x+3,28,2,17,0xcf6650);r(x+7,29,2,14,0xe3a458);r(x+2,45,12,2,0xe3b45e);r(x+7,47,2,9,0xc98748)}r(313,27,12,27,0xab4637);r(318,32,2,17,0xe4b96d)}
 // rug
 r(119,128,125,80,0x443526,.15);r(120,125,120,79,t.rug);r(124,129,112,71,0xf2d8b1);r(126,131,108,67,t.rug);for(let x=126;x<234;x+=6){r(x,125,2,3,0xe8d4b4);r(x,201,2,5,0xe8d4b4)}for(let x=131;x<232;x+=8)r(x,135,3,2,0xf5e1c5,.6);
 // bookshelf and books
 r(34,64,45,40,0x3e302b,.2);r(32,53,45,46,0x65483a);r(35,55,39,41,0x916b49);for(let row=0;row<2;row++){for(let i=0;i<7;i++){const h=10+i%3*2;r(38+i*5,73+row*18-h,4,h,[0x809b89,0xc27d68,0xdac18a,0x7c7b91][i%4]);r(39+i*5,75+row*18-h,2,1,0xf7dfaf)}r(34,74+row*18,41,3,0x5e4436)}r(30,51,49,4,0xc19665);
 // plant shadows, layered leaves
 r(261,96,25,6,0x4a392b,.2);r(264,83,17,17,0xa56349);r(267,87,3,10,0xc98b62);r(262,82,21,4,0xdba16e);r(271,58,2,25,0x4d704a);for(const [x,y,w,c] of [[258,66,13,0x769660],[274,60,13,0x85a36c],[264,53,9,0x5c8052],[274,74,12,0x557b51],[260,76,11,0x91a774]]){r(x,y,w,6,c);r(x+2,y-2,w-4,3,c)}
 // dresser
 r(251,173,41,8,0x49392f,.2);r(251,151,38,28,0x654638);r(249,148,42,5,0xd5a16c);for(let i=0;i<2;i++){r(254,155+i*11,32,8,0xaf8057);r(255,155+i*11,30,1,0xe1b680);r(268,158+i*11,5,2,0xf0d392)}r(253,179,4,4,0x654638);r(283,179,4,4,0x654638);
 // mailbox with envelope
 r(55,191,20,24,0x69513e);r(53,180,25,22,this.mode==='newyear'?0x9d4d3d:0x718b7d);r(55,182,21,2,0xb7c2a2);r(57,186,15,2,0x3b5449);r(63,192,5,6,0xe7c16d);r(64,193,3,2,0x6b5940);r(56,213,4,4,0x554335);r(71,213,4,4,0x554335);
 // seat and cushions
 r(101,217,34,22,0x596a59);r(104,214,28,20,0xaab59b);r(107,217,22,14,0xc6c9a8);r(109,219,18,1,0xe6dec0);r(298,114,28,25,0x785d4a);r(301,111,22,23,this.mode==='birthday'?0xc591aa:0xe1bb86);r(304,114,16,13,0xf3d6a9);
 // table with themed centerpiece
 r(145,169,67,10,0x503a2e,.2);r(149,164,5,15,0x775139);r(204,164,5,15,0x775139);r(145,146,67,25,0x8e603e);r(147,144,63,23,0xe2b782);r(150,147,57,1,0xf2d0a0);
 if(this.mode==='birthday'){r(158,146,37,16,0xe9d4c6);r(161,140,31,17,0xd397a5);r(161,138,31,6,0xffead1);for(let x=164;x<191;x+=7)r(x,143,3,4,0xf9ddbc);for(const x of [169,178,185]){r(x,132,2,6,0x86a4a0);r(x,129,2,3,0xffc36b)}for(const [x,y,c] of [[92,103,0xd698ad],[316,79,0x9b92bc],[305,59,0xe7b77c]]){r(x+5,y+12,1,23,0xdcc3ae);r(x+2,y,9,15,c);r(x,y+3,13,9,c);r(x+3,y+2,2,4,0xffe5d5)}r(277,214,23,19,0xb98ca7);r(287,214,3,19,0xf3d6aa);r(275,212,27,4,0xe2adbe);r(300,221,17,14,0xd6b16f);r(306,221,3,14,0xf6dfb5)}
 else if(this.mode==='newyear'){r(157,149,16,12,0xa94937);r(159,147,12,3,0xd7ac62);r(163,152,4,5,0xefcb81);r(182,151,15,9,0xddd0ac);r(184,149,11,3,0xf3e2b4);r(185,151,3,2,0xd08d50);r(284,214,28,19,0x9d3c32);r(296,216,4,13,0xeac16f);r(281,212,34,4,0xce6950);for(let i=0;i<4;i++){r(37+i*6,121+i*6,5,8,0xae4937);r(38+i*6,121+i*6,3,2,0xe8bc70)}}
 else{r(157,151,12,9,0xf4e1bd);r(159,153,8,4,0x90664a);r(169,153,3,4,0xf4e1bd);r(178,149,21,13,0x6f8d7c);r(180,151,8,9,0xf1d9b2);r(190,151,7,9,0xe6cda4);r(188,150,1,11,0xa08a66);r(309,165,3,38,0x69563f);r(297,162,27,3,0xe2cba0);r(302,146,17,16,0xf1d6a2);r(304,144,13,2,0xf8e6bf);r(303,202,17,3,0x69563f)}
 // tiny wall frames and soft edge lighting
 r(40,25,22,17,0x977553);r(42,27,18,13,0xf4dfb8);r(46,34,10,5,0x8b9d7c);r(50,29,4,4,0xe1b778);r(24,68,312,3,0x342b2a,.12);
 drawGarden(this,this.mode);r(336,202,24,40,t.floor);r(333,199,4,44,0xc3a373);r(336,201,24,3,0xe7c590);this.add.text(307,222,'花园 →',{fontSize:'7px',color:'#f6e5b7'});this.add.text(365,205,'← 小屋',{fontSize:'7px',color:'#fff0c8'});this.cameras.main.setBounds(0,0,720,270);this.player=this.add.container(447,235);const p=this.add.graphics();p.fillStyle(0x382e2b,.22).fillEllipse(0,5,17,6);p.fillStyle(0x4b3935).fillRect(-6,-24,11,8).fillRect(-7,-21,3,11);p.fillStyle(0x79513c).fillRect(-4,-24,8,3);p.fillStyle(0xf2c5a0).fillRect(-4,-18,9,9);p.fillStyle(0xdba385).fillRect(4,-14,2,3);p.fillStyle(0x483830).fillRect(2,-16,2,2);p.fillStyle(0xe2a490).fillRect(1,-12,3,2);p.fillStyle(this.mode==='birthday'?0xc78fa2:this.mode==='newyear'?0xb35443:0x8d9d7e).fillRect(-5,-9,11,10);p.fillStyle(0xf2e0bd).fillRect(-4,-9,9,2);p.fillStyle(0xefd0a7).fillRect(-6,-5,3,6).fillRect(5,-5,3,6);p.fillStyle(0x515c58).fillRect(-4,1,4,5).fillRect(2,1,4,5);p.fillStyle(0x46392f).fillRect(-5,5,5,2).fillRect(2,5,5,2);this.player.add(p);this.cameras.main.startFollow(this.player,true,.08,.08);
 // floating dust / confetti particles
 for(let i=0;i<12;i++){const x=40+(i*47)%280,y=78+(i*37)%150;const mote=this.add.rectangle(x,y,this.mode==='birthday'?2:1,this.mode==='birthday'?3:1,this.mode==='newyear'?0xf1bc68:this.mode==='birthday'?[0xffdfad,0xf7c4d3,0xb5c6b1][i%3]:0xffe8b0,.45);this.tweens.add({targets:mote,y:y-9,alpha:.1,duration:2000+i*120,yoyo:true,repeat:-1})}
 this.hint=this.add.text(180,248,'',{fontSize:'10px',color:'#fff3d6',backgroundColor:'#493c35',padding:{x:9,y:4}}).setOrigin(.5).setDepth(10).setScrollFactor(0);
 this.keys=this.input.keyboard!.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT,E') as Record<string,Phaser.Input.Keyboard.Key>;
 }
 update(time:number,dt:number){if(this.locked){this.hint.setVisible(false);return}const k=this.keys;const dx=Number(k.D.isDown||k.RIGHT.isDown)-Number(k.A.isDown||k.LEFT.isDown),dy=Number(k.S.isDown||k.DOWN.isDown)-Number(k.W.isDown||k.UP.isDown);if(dx)this.player.setScale(dx<0?-1:1,1);const speed=65*Math.min(dt,40)/1000/(dx&&dy?Math.SQRT2:1);
 const blocked=(x:number,y:number)=>{if(x>=350)return x>689||y<55||y>241||gardenObjects.some(f=>x>f.x-f.w/2-6&&x<f.x+f.w/2+6&&y>f.y-f.h/2&&y<f.y+f.h/2+6)||(x<416&&y<181)||(x>639&&y<101);if(x>327)return y<200||y>241;return x<33||y<81||y>237||furniture.some(f=>x>f.x-f.w/2-6&&x<f.x+f.w/2+6&&y>f.y-f.h/2-3&&y<f.y+f.h/2+7)||(x>139&&x<219&&y>143&&y<180)||(x>96&&x<140&&y>214&&y<241)||(x>293&&x<331&&y>111&&y<143)};
 let x=this.player.x+dx*speed,y=this.player.y;if(!blocked(x,y))this.player.x=x;y+=dy*speed;if(!blocked(this.player.x,y))this.player.y=y;this.moving=!!(dx||dy);this.player.first?.setData('moving',this.moving);const body=this.player.list[0] as Phaser.GameObjects.Graphics;body.y=this.moving?Math.round(Math.sin(time/85)):0;
 this.near=[...furniture,...gardenObjects].find(f=>Phaser.Math.Distance.Between(this.player.x,this.player.y,f.x,f.y+f.h/2)<38);this.hint.setVisible(!!this.near);if(this.near)this.hint.setText('E · 探索'+this.near.name);if(Phaser.Input.Keyboard.JustDown(k.E)&&this.near)this.onExplore(this.near);
 }
}


