# MomentGift

本地单人互动贺卡 Demo，React + TypeScript + Vite + Phaser 3 + Tailwind CSS。

## 启动

在此目录运行：

```powershell
npm install
npm run dev
```

打开终端显示的本地地址。生产构建：`npm run build`，预览：`npm run preview`。

## 项目结构

- src/game/Room.ts：像素绘制、移动、碰撞、邻近交互
- src/game/config.ts：家具位置与探索文本
- src/data/gift.ts：本地贺卡数据
- src/main.tsx：React 页面、对话框、钥匙状态与重玩生命周期
- src/style.css：Tailwind 入口与页面样式

## 游玩

方向键 / WASD 移动，靠近家具按 E。抽屉里有钥匙，带着钥匙探索信箱即可展开祝福。点击继续探索（或 Enter / Escape）关闭对话框。重玩会重置人物和钥匙。

像素画布为 360×270，桌面整数放大 2 倍，小屏 1 倍。素材由代码绘制，无外部图片和 emoji 素材。不包含数据库、登录、编辑器或在线分享后端。

## 第二版功能

首页先设置普通 / 生日 / 新年模式、收发信人、标题、祝福、问题、答案和钥匙藏处（抽屉 / 书架 / 花盆）。答对问题才会获得钥匙；答错可继续尝试。角色会随着左右移动改变朝向。

配置编码在 URL hash 中，刷新可恢复。生成的本地链接只能本机访问，部署后同一路径可分享。答案也包含在链接中，不适合安全验证或敏感信息。所有数据仍无数据库存储。

UI 位于 src/components/App.tsx、src/components/Setup.tsx；配置类型与链接解析位于 src/data/settings.ts。

## 花园版本
地图扩展到 720×270，360×270 镜头跟随角色。花园新增池塘、长椅、花圃、入口路牌及灯串；进入时显示玩法提示。解锁贺卡播放双侧彩纸动画，重玩会清理并重新触发。Garden.ts 负责花园绘制，Celebration.tsx 负责庆祝特效。
